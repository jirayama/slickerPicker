# slickerPicker
a vanilla Javascript color picker
